//------------------------------------------------------------------------------
//
// Copyright (c) 2012, Sebastian Sapeta
//  Modified for DPS gluon by Tomoki Goda, 21/10/2022.
//
//  This is part of KSgluon package.
//
//  KSgluon is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  KSgluon is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with FastJet; if not, write to the Free Software
//  Foundation, Inc.:
//      59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//------------------------------------------------------------------------------

#include <iostream>
#include<fstream>
#include <string>
#include "UnintegratedGluonDPS.hh"
#include "InterpolationDPS.hh"

using namespace std;

int main(int argc, char ** argv) {


  /// Set interpolation type: 
  ///   *gsl_interp_linear 
  ///   *gsl_interp_cspline
  gsl_interp_type int_type =  *gsl_interp_cspline;

  /// Choose the grid:
  
  string gridfile =  "grids/GBW-gluon.dat";
  //string gridfile =  "grids/GBW-Sudakov-gluon.dat";
  //string gridfile =  "grids/BGK-gluon.dat";
  //string gridfile =  "grids/BGK-Sudakov-gluon.dat";
  //string gridfile =  "grids/GBW-dipole.dat";
  //string gridfile =  "grids/GBW-Sudakov-dipole.dat";
  //string gridfile =  "grids/BGK-dipole.dat";
  //string gridfile =  "grids/BGK-Sudakov-dipole.dat";
  
  
  std::cout<<"Start computing"<<std::endl;	  

  /// Created updf object
  //UnintegratedGluon updf = UnintegratedGluon(gridfile,int_type);
  UnintegratedGluon updf = UnintegratedGluon(gridfile,int_type);


 
  /// Use interpolation
  double kt = 1.0;
  double mu =  1.0;
  cout << "# --------------------------------------------------------" << endl;
  cout << "# "<< gridfile           << endl;
  cout << "# mu = " << mu << " GeV" << endl;
  cout << "# kt = " << kt << " GeV" << endl;
  cout << "# --------------------------------------------------------" << endl;
  cout << "#   x     \t  xg(x,kt)"     << endl; 
  cout << "#" << endl;
  //cout << "# --------------------------------------------------------" << endl;
  unsigned int npoints = 20;
  for (unsigned i = 0; i<npoints; i++) {
      double logx = -15.0 + 13.0*i/npoints;
      // 3rd argument is relevant only for the KShardscale grids
      cout << exp(logx) << "\t" << updf.xg(logx,log(kt*kt), log(mu*mu)) << endl;
  }


  // Using for dipole cross section
 /* double logx = -9.0;
  double mu =  1.0;
  cout << "# --------------------------------------------------------" << endl;
  cout << "# "<< gridfile           << endl;
  cout << "# mu = " << mu << " GeV" << endl;
  cout << "# x = " << exp(logx) << "  " << endl;
  cout << "# --------------------------------------------------------" << endl;
  cout << "#   r    \t  x sigma(x,r)"     << endl; 
  cout << "#" << endl;
  //cout << "# --------------------------------------------------------" << endl;
  unsigned int npoints = 20;
  for (unsigned i = 0; i<npoints; i++) {
      double r = pow(10,-3 + (5.0*i)/npoints);
      // 3rd argument is relevant only for the KShardscale grids
      cout << r << "\t" << updf.xg(logx,log(r), log(mu*mu)) << endl;
  }*/

}
